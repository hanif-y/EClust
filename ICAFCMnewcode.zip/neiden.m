function z=neiden(Mdl1,x,y,e,zold)
m=[x;y];
m1=mean(m);
Idx = rangesearch(Mdl1,m1,e,'Distance','minkowski','P',zold);
% z=2+(size(Idx{1,1},2)./size(Mdl1.X,1));
z=size(Idx{1,1},2);
if z==0
    z=1;
end