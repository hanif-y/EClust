R={};
for kk=1:size(tr,2)
    R{1,kk}=(Q(1,tr(:,kk)))';
end

i=1;
j=2;
n=0;
while i~=(size(R,2)-1) 
    for j=(i+1):size(R,2)    
 m=intersect(R{1,i},R{1,j});
 if ~isnan(m)
     sd=min(i,j);
     sq=max(i,j);
     R{1,sd}=union(R{1,i},R{1,j});
     R{1,sq}=[];
     i=1;
     n=n+1;
%  break;    
 end
 j=j+1;
    end
    if n~=0
        i=1;
        n=0;
    elseif n==0
      i=i+1;
    end
end
