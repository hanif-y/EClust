Idx=DDkmeans(data,5,4);
[sum(Idx==5) sum(Idx==4) sum(Idx==3) sum(Idx==2) sum(Idx==1)]




