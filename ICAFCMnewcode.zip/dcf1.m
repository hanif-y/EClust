function z=dcf1(x)
global params;
data=params;
cc=x(1,1);
m=x(1,2);
xx=x(1,3);
ic=x(4:end);

icc=data(ic,:);
% [~,~,~,error] = dcFuzzy(data,cc,m,icc);
[~,~,error] = fcm(data,cc,[m 20 0.00001 0]);
z=(1/xx)*min(error)+xx*cc/(2+round(log(size(data,1))));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  ICAFCM CLuSTERING                                            %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%