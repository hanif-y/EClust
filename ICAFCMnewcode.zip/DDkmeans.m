function [Idx,D2]=DDkmeans(data,k,e)
Mdl1 = ExhaustiveSearcher(data);
[C,~]=ChooseInitialCentres(data,k);
Cold=C;
zold=2;
D2=[];
maxit=100;
change=1;
while change>=0.0000001
    for kk=1:k
    for j=1:size(data,1)
    z=neiden(Mdl1,data(j,:),C(kk,:),e,zold);
    zold=z;
%     D2(j,kk) = pdist2(data(j,:),C(kk,:),'minkowski',z);
    D2(j,kk) = (pdist2(data(j,:),C(kk,:)))/z;
    end
    end
    [~,Centre]=min(D2,[],2);
    Cold=C;
    for kk=1:k
      id=Centre==kk;
      C(kk,:)=mean(data(id,:));
    end
    change=sum(sum(abs(Cold-C)));
end
   [~,Idx]=min(D2,[],2);  