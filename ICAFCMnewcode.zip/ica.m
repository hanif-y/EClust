%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  ICAFCM CLuSTERING                                            %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


global iteration
global Nimp
global Nc
global Sol;

%% Problem Definition

CostFunction=@(x)dcf(x);


%% ICA Settings

nPop=Nc;     % Number of Countries
nImp=Nimp;      % Number of Imperials
nCol=nPop-nImp;

MaxDecades=iteration;

beta=1;

pRevolution=0.5;

zeta=0.02;

%% Initialization

ShareSettings;

imp=InitializeImperials();

BestSol.Position=[];
BestSol.Cost=[];

BestCost=zeros(ICASettings.MaxDecades,1);
MeanCost=zeros(ICASettings.MaxDecades,1);
h = waitbar(0,'please wait.....');
%% ICA
for Decade=1:MaxDecades
    
    imp=AssimilateColonies(imp);
    
    imp=RevolveColonies(imp);
    
    imp=ExchangeWithBestColony(imp);
    
    imp=CalculateTotalCosts(imp);
    
    imp=ImperialisticCompetition(imp);

    ImpCost=[imp.Cost];
    [BestImpCost BestImpIndex]=min(ImpCost);
    BestImp=imp(BestImpIndex);
    
    BestSol.Position=BestImp.Position;
    BestSol.Cost=BestImp.Cost;
    
    BestCost(Decade)=BestImpCost;
    MeanCost(Decade)=mean(ImpCost);
    
%     disp(['Decade ' num2str(Decade) ...
%           ': Best Cost = ' num2str(BestCost(Decade)) ...
%           ', Mean Cost = ' num2str(MeanCost(Decade)) ...
%           ', nImp = ' num2str(numel(imp))]);
 waitbar(Decade/MaxDecades);     
end
close(h)
figure(1);
semilogy(BestCost,'b','LineWidth',2);
hold on;
semilogy(MeanCost,'r:','LineWidth',2);
legend('Best Cost','Mean Cost');
xlabel('Decade');
% [class,U,centres,error]=dcff(BestSol.Position);
Sol=BestSol.Position;