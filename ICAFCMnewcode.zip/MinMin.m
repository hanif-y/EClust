function M = MinMin(x)
%MINMIN Minimum of all elements in an n-dimension array
% S = MINMIN(X)
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  ICAFCM CLuSTERING                                            %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

M=x;
for i = 1:ndims(x)
   M=min(M);
end
