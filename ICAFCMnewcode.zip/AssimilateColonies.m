%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  ICAFCM CLuSTERING                                            %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function imp=AssimilateColonies(imp)

    global ProblemSettings;
    global ICASettings;
    
    CostFunction=ProblemSettings.CostFunction;
    
    
    beta=ICASettings.beta;
    
    for i=1:numel(imp)
        for j=1:imp(i).nCol
            d=imp(i).Position(1,2)-imp(i).Colonies(j).Position(1,2);
            x=beta*rand.*d;
            imp(i).Colonies(j).Position(1,2)=imp(i).Colonies(j).Position(1,2)+x;
            imp(i).Colonies(j).Position(1,2)=min(max(imp(i).Colonies(j).Position(1,2),1),2);
            d1=imp(i).Position(1,3)-imp(i).Colonies(j).Position(1,3);
            x1=beta*rand.*d1;
            imp(i).Colonies(j).Position(1,3)=imp(i).Colonies(j).Position(1,3)+x1;
            imp(i).Colonies(j).Position(1,3)=min(max(imp(i).Colonies(j).Position(1,3),1),10);
            
            k1=min([size(imp(i).Colonies(j).Position) size(imp(i).Position)]);
%             k2=unidrnd(k1);
         for l=4:k1
             if sum(imp(i).Colonies(j).Position(4:end)==imp(i).Position(l))==0
            imp(i).Colonies(j).Position(1,l)=imp(i).Position(l);
             end
         end
            

          imp(i).Colonies(j).Cost=CostFunction(imp(i).Colonies(j).Position);  
        end
    end
    
end