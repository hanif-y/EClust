%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  ICAFCM CLuSTERING                                            %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function imp=ExchangeWithBestColony(imp)

    for i=1:numel(imp)
        
        cc=[imp(i).Colonies.Cost];
        [min_cc min_cc_index]=min(cc);
        
        if min_cc<=imp(i).Cost
            
            BestColony=imp(i).Colonies(min_cc_index);
            
            imp(i).Colonies(min_cc_index).Position=imp(i).Position;
            imp(i).Colonies(min_cc_index).Cost=imp(i).Cost;
            
            imp(i).Position=BestColony.Position;
            imp(i).Cost=BestColony.Cost;
            
        end
        
    end

end