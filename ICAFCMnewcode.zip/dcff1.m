function [class,U,centres,error]=dcff1(x)
global params;
data=params;
cc=x(1,1);
m=x(1,2);
ic=x(4:end);
r=size(data,2);
icc=data(ic,:);

[centres,U,error] = fcm(data,cc,[m 100 0.000001 0]);
y=U==max(U);
[class, ~]=find(y==1);
class=class';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  ICAFCM CLuSTERING                                            %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%