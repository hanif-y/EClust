function [class,U,centres,error]=dcff(x)
global params;
data=params;
cc=x(1,1);
m=x(1,2);
ic=x(4:end);
r=size(data,2);
icc=data(ic,:);
[class,U,centres,error] = dcFuzzy(data,cc,m,icc,20);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  ICAFCM CLuSTERING                                            %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%