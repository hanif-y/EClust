%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  ICAFCM CLuSTERING                                            %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Problem Definition
global ProblemSettings;
ProblemSettings.CostFunction=CostFunction;


%% ICA Settings
global ICASettings;
ICASettings.nPop=nPop;
ICASettings.nImp=nImp;
ICASettings.nCol=nPop-nImp;
ICASettings.MaxDecades=MaxDecades;
ICASettings.beta=beta;
ICASettings.pRevolution=pRevolution;
ICASettings.zeta=zeta;
