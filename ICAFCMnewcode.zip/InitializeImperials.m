%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  ICAFCM CLuSTERING                                            %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function imp=InitializeImperials()

    global ProblemSettings;
    global ICASettings;
   
    CostFunction=ProblemSettings.CostFunction;
    
    
    nPop=ICASettings.nPop;
    nImp=ICASettings.nImp;
    nCol=ICASettings.nCol;
    
    EmptyColony.Position=[];
    EmptyColony.Cost=[];
    
    Colonies=repmat(EmptyColony,nPop,1);

    global params;
    data=params;
    r=size(data,2);
    
    for k=1:nPop
        m=unifrnd(1,2);
        xx=unifrnd(2,10);
        cc=unidrnd(3);
        perm = randperm(size(data,1));
        perm1 = perm(1:cc);

        Colonies(k).Position=([cc m xx perm1]);

        Colonies(k).Cost=CostFunction(Colonies(k).Position);
    end

    [~, CostsSortOrder]=sort([Colonies.Cost]);
    Colonies=Colonies(CostsSortOrder);
    
    EmptyImperial.Position=[];
    EmptyImperial.Cost=[];
    EmptyImperial.TotalCost=[];
    EmptyImperial.nCol=[];
    EmptyImperial.Colonies=[];
    
    imp=repmat(EmptyImperial,nImp,1);
    for i=1:nImp
        imp(i).Position=Colonies(i).Position;
        imp(i).Cost=Colonies(i).Cost;
    end
    
    Colonies=Colonies(nImp+1:end);
    if isempty(Colonies)
        return;
    end
    
    ImpCosts=[imp.Cost];
    MaxImpCost=max(ImpCosts);
    ImpFitness=1.2*MaxImpCost-ImpCosts;
    p=ImpFitness/sum(ImpFitness);
    nc=abs(round(p*nCol));
    snc=sum(nc);
    
    if snc>nCol
        i=1;
        while snc>nCol
            nc(i)=max(nc(i)-1,0);
            i=i+1;
            if i>nImp
                i=1;
            end
            snc=sum(nc);
        end
    elseif snc<nCol
        i=nImp;
        while snc<nCol
            nc(i)=nc(i)+1;
            i=i-1;
            if i<1
                i=nImp;
            end
            snc=sum(nc);
        end
    end
    
    Colonies=Colonies(randperm(nCol));
    
    for i=1:nImp
        imp(i).nCol=nc(i);
        imp(i).Colonies=Colonies(1:nc(i));
        Colonies=Colonies(nc(i)+1:end);
    end
    
end