function S = SumSum(x)
%SUMSUM Sums all elements in an n-dimension array
% S = SUMSUM(X)
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  ICAFCM CLuSTERING                                            %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

S=x;
for i = 1:ndims(x)
   S=sum(S);
end
