%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  ICAFCM CLuSTERING                                            %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function imp=RevolveColonies(imp)

    global ProblemSettings;
    global ICASettings;
    
    CostFunction=ProblemSettings.CostFunction;

    
    pRevolution=ICASettings.pRevolution;
    global params;
    data=params;
    for i=1:numel(imp)
        for j=1:imp(i).nCol
            if rand<pRevolution
                x1=randi([-1 1]);
            
            k5=imp(i).Colonies(j).Position(1,1);
            if k5>1&&x1<0
                imp(i).Colonies(j).Position(1,1)=imp(i).Colonies(j).Position(1,1)+x1;
                k3=imp(i).Colonies(j).Position(1,1);
              ux= imp(i).Colonies(j).Position; 
              imp(i).Colonies(j).Position=NaN(1,k3+3);
              imp(i).Colonies(j).Position(1:k3+3)=ux(1:k3+3);  
            end
            if x1>0&&k5<size(data,1)/2
                imp(i).Colonies(j).Position(1,1)=imp(i).Colonies(j).Position(1,1)+x1;
                k3=imp(i).Colonies(j).Position(1,1);
              ux= imp(i).Colonies(j).Position; 
              imp(i).Colonies(j).Position=NaN(1,k3+3);
              imp(i).Colonies(j).Position(1:k5+3)=ux(1:k5+3); 
              tbag=randi([1 size(data,1)]);
              while sum(ux(1,4:end)==tbag)~=0
                  tbag=randi([1 size(data,1)]);
              end
              imp(i).Colonies(j).Position(end)=tbag;
            end
            if rand<1

            for k=randi([4 size(imp(i).Colonies(j).Position,2)],[1 round(imp(i).Colonies(j).Position(1,1)/2)+1])
                 tbag=randi([1 size(data,1)]);
                while sum(imp(i).Colonies(j).Position(4:end)==tbag)~=0
                tbag=randi([1 size(data,1)]);
                end
                imp(i).Colonies(j).Position(k)=tbag;
             end
            end
       
                imp(i).Colonies(j).Cost=CostFunction(imp(i).Colonies(j).Position);
            end
        end
    end

end