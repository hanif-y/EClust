function z=dcf(x)
global params;
data=params;
cc=x(1,1);
m=x(1,2);
xx=x(1,3);
ic=x(4:end);

icc=data(ic,:);
[~,~,~,error] = dcFuzzy(data,cc,m,icc,3);
% r1=class';
% if size(r1,1)==size(data,1)
% g=silhouette(params,r1);
% else
% g=0;
% end
z=(1/xx)*(error)+xx*cc/(2+round(log10(size(data,1))));
% z=(error);
% z=-1*mean(g);
% z=(mean(error)*cc^(2*mean(error)));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MATLAB Code for                                               %
%                                                               %
%  ICAFCM CLuSTERING                                            %
%                                                               %
%                                                               %
%    Programmed By: H.yaghoobi                                  %
%                                                               %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%