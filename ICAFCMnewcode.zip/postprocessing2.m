global params
global Dy;
global merg
global mergm;
global mergo;
global Sol;
global class;
global cri;
global cri1;
global cri2;
global cri3;
global U;
global Ev;
global EV1;
U1=[];
Ev=[];
mn1=0;
h = waitbar(0,'please wait.....');
class3=class;
aa=merg:0.005:mergm;
for mn=aa
    merg1=mn;
%     mn1=mn1+1;
class2=class;
Data=params;

C1={};
Dy1=[];

CS=corrcoef(Dy');
tr=CS>=merg1;

Q=1:Sol(1,1);
R={};
for kk=1:size(tr,2)
    R{1,kk}=(Q(1,tr(:,kk)))';
end

i=1;
j=2;
n=0;
while i~=(size(R,2)-1) 
    for j=(i+1):size(R,2)    
 m=intersect(R{1,i},R{1,j});
 if ~isnan(m)
     sd=min(i,j);
     sq=max(i,j);
     R{1,sd}=union(R{1,i},R{1,j});
     R{1,sq}=[];
     i=1;
     n=n+1;
%  break;    
 end
 j=j+1;
    end
    if n~=0
        i=1;
        n=0;
    elseif n==0
      i=i+1;
    end
end
g=0;
for k=1:size(R,2)
     if ~isnan(R{1,k})
         g=g+1;
s=class2==R{1,k};
s=sum(s);
s=s==1;

class2(1,s)=min(R{1,k});
U1(g,:)=sum(U(R{1,k},:),1);
    end
end
if ~isequal(class2,class3)
    
Lia = ismember(Q,class2);
i=0;

for k=find(Lia==1)
    i=i+1;
  A1{i}=Data(class2==k,:);
 if size(A1{1,i},1)>1 
  C1{i}=mean(A1{1,i});
 else
  C1{i}=(A1{1,i});
 end
end  

for i=1:size(C1,2)
    Dy1(i,:)=C1{1,i};
end
mn1=mn1+1; 
aa1(mn1)=mn;
Ev(mn1,1) = Vpc(U1);
Ev(mn1,2) = Vpe(size(C1,2),U1);
Ev(mn1,3) = Vfs(params,size(C1,2),Dy1,U1,Sol(1,2));
Ev(mn1,4) = Vxie(params,size(C1,2),Dy1,U1,Sol(1,2));
Ev(mn1,5) = Vrlr(params,size(C1,2),Dy1,U1,Dis([],size(C1,2),Dy1));
if cri1==1
eva1 = evalclusters(params,class2','Silhouette');
Ev(mn1,6)=mean(eva1.ClusterSilhouettes{1,1});
else 
Ev(mn1,6)=nan;
end
if cri2==1
eva2 = evalclusters(params,class2','DaviesBouldin'); 
Ev(mn1,7)=eva2.CriterionValues;
else
Ev(mn1,7)=nan;
end
if cri3==1
eva3 = evalclusters(params,class2','CalinskiHarabasz'); 
Ev(mn1,8)=eva3.CriterionValues;
else
Ev(mn1,8)=nan;
end

end
class3=class2;
waitbar(mn/mergm);
end

EV1={};
EV1(1,2)={'Partition Coefficient'};
EV1(1,3)={'Partition Entropy'};
EV1(1,4)={'Fakuyama & Sugeno'};
EV1(1,5)={'Xie & Beni Index'};
EV1(1,6)={'Rezaee et al'};
EV1(1,7)={'Silhouette'};
EV1(1,8)={'DaviesBouldin'};
EV1(1,9)={'CalinskiHarabasz'};
for ii=1:size(Ev,2)
    for jj=1:size(Ev,1)
EV1{jj+1,ii+1}=num2str(Ev(jj,ii));
    end
end
EV1(1,1)={'Merging Parameter'};
for jj=1:size(Ev,1)
EV1{jj+1,1}=num2str(aa1(1,jj)');
end
if strcmp(cri,'Silhouette')
kk=Ev(:,6)==max(Ev(:,6));
elseif strcmp(cri,'DaviesBouldin')
kk=Ev(:,7)==min(Ev(:,7)); 
elseif strcmp(cri,'CalinskiHarabasz')
kk=Ev(:,8)==max(Ev(:,8)); 
end
for i=1:size(EV1,1)
    for j=1:size(EV1,2)
        if isempty(EV1{i,j})
            EV1{i,j}='';
        end
    end
end

mergo=aa1(1,find(kk==1,1));

figure(7)
subplot(4,2,1)
stairs(aa1,Ev(:,1),'LineWidth',2);
%     plot(aa1,Ev(:,1),'LineWidth',2);
    title('Partition Coefficient');
    grid on;
    ax = gca;
   ax.FontSize = 12;
   ax.LineWidth=1.5;
   
subplot(4,2,2)
    stairs(aa1,Ev(:,2),'LineWidth',2);
    title('Partition Entropy');
   grid on;
    ax = gca;
   ax.FontSize = 12;
   ax.LineWidth=1.5;
   
subplot(4,2,3)
    stairs(aa1,Ev(:,3),'LineWidth',2);
    title('Fakuyama & Sugeno');
    grid on;
    ax = gca;
   ax.FontSize = 12;
   ax.LineWidth=1.5;
    
subplot(4,2,4)
    stairs(aa1,Ev(:,4),'LineWidth',2);
    title('Xie & Beni Index');
    grid on;
    ax = gca;
   ax.FontSize = 12;
   ax.LineWidth=1.5;
    
 subplot(4,2,5)
    stairs(aa1,Ev(:,5),'LineWidth',2);
    title('Rezaee et al');
   grid on;
    ax = gca;
   ax.FontSize = 12;
   ax.LineWidth=1.5;
    
 subplot(4,2,6)
    stairs(aa1,Ev(:,6),'LineWidth',2);
    title('Silhouette');
    grid on;
    ax = gca;
   ax.FontSize = 12;
   ax.LineWidth=1.5;

  subplot(4,2,7)
   stairs(aa1,Ev(:,7),'LineWidth',2);
    title('DaviesBouldin');
    grid on;
    ax = gca;
   ax.FontSize = 12;
   ax.LineWidth=1.5;
   
  subplot(4,2,8)
   stairs(aa1,Ev(:,8),'LineWidth',2);
    title('CalinskiHarabasz');
    grid on;
    ax = gca;
   ax.FontSize = 12;
   ax.LineWidth=1.5;
   close(h);