[centers,u] = fcm(params,3);
[~,class20]=max(u);
eva = evalclusters(params,class20','Silhouette');
mean(eva.ClusterSilhouettes{1,1});